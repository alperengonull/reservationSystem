const net = require("net");
const mongoose = require("mongoose");

const port = 8081;

// Parse request
function parseRequest(data) {
  const [requestLine, ...rest] = data.toString().split("\r\n");
  const [method, path] = requestLine.split(" ");

  // Split the path by "?" and take the first element to get the path without the query string
  const [pathWithoutQueryString] = path.split("?");

  // Parse query string
  const queryString = path.split("?")[1] || "";
  const queryParams = queryString.split("&").reduce((params, param) => {
    const [key, value] = param.split("=");
    params[key] = value;
    return params;
  }, {});

  return {
    method,
    path: pathWithoutQueryString,
    queryParams,
  };
}

// I am connecting to mongodb
mongoose.connect("mongodb://127.0.0.1/room-reservation", {
  useNewUrlParser: true,
});

// mongodb models
const Room = require("./models/room");
const Reservation = require("./models/reservation");
const Activity = require("./models/activity");

const db = mongoose.connection;
db.on("error", function (error) {
  console.log(error);
});
db.once("open", function () {
  const server = net.createServer((socket) => {
    console.log("New connection");

    // Handle data from client
    socket.on("data", async (data) => {
      const { method, path, queryParams } = parseRequest(data);

      // Check if the request is GET, otherwise return 403
      if (method !== "GET") {
        const response = `
        <HTML>
        <HEAD>
        <TITLE>ERROR</TITLE>
        </HEAD>
        <BODY>
        Server is only accepting GET requests.
        </BODY>
        </HTML>
        `;
        socket.write(
          `HTTP/1.1 403 Bad Request\r\nContent-Length: ${response.length}\r\n\r\n${response}`
        );
        return;
      }

      switch (path) {
        case "/add": {
          const { name } = queryParams;
          const checkifExist = await Room.findOne({ name: name });

          if (checkifExist) {
            // There is exists room with this name
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Exists Room</TITLE>
            </HEAD>
            <BODY>
            There is exists room with name ${name}
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 403 Forbidden\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
            return;
          }
          try {
            await Room.create({ name: name });
            //  I will create a room
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Room Added</TITLE>
            </HEAD>
            <BODY>
            Room with name ${name} is successfully added.
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 200 OK\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          } catch (error) {
            console.log(error);
            const response = "Error creating room";
            socket.write(
              `HTTP/1.1 500 Internal Server Error\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          }
          break;
        }

        case "/remove": {
          const { name } = queryParams;
          const checkifNotExist = await Room.findOne({
            name: name,
          });

          // I will check if there is any room with this name
          if (!checkifNotExist) {
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Error</TITLE>
            </HEAD>
            <BODY>
            Room with name ${name} is not found.
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 403 Forbidden\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
            return;
          }
          try {
            // I will remove the room
            await Room.deleteOne({ name: name });
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Room removed</TITLE>
            </HEAD>
            <BODY>
            Room with name ${name} removed.
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 200 OK\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          } catch (error) {
            console.log(error);
            const response = "Error creating room";
            socket.write(
              `HTTP/1.1 500 Internal Server Error\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          }
          break;
        }

        case "/reserve": {
          const { name, hour, duration, day } = queryParams;

          // Is there any room with this name
          const findRoom = await Room.findOne({ name: name });

          if (!findRoom) {
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Not Exists Room</TITLE>
            </HEAD>
            <BODY>
            There is not exists room with name ${name}.
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 400 Bad Request\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
            return;
          }

          try {
            // Is there any reservation in this room in this day and hour
            const searchRoomInReservation = await Reservation.findOne({
              room_name: name,
              day: day,
              hour: hour,
            });
            if (searchRoomInReservation) {
              // Room is already reserved
              const response = `
            <HTML>
            <HEAD>
            <TITLE>Room is already reserved</TITLE>
            </HEAD>
            <BODY>
              ${name} is already reserved.
            </BODY>
            </HTML>
            `;
              socket.write(
                `HTTP/1.1 403 Forbidden\r\nContent-Length: ${response.length}\r\n\r\n${response}`
              );
              return;
            }

            const numberToDay = {
              1: "Monday",
              2: "Tuesday",
              3: "Wednesday",
              4: "Thursday",
              5: "Friday",
              6: "Saturday",
              7: "Sunday",
            };

            const checkHour = hour >= 9 && hour <= 17;
            const checkDuration = duration > 0 && duration <= 24;

            if (!numberToDay[day] || !checkHour || !checkDuration) {
              // If there is invalid day,hour or duration
              const response = `
            <HTML>
            <HEAD>
            <TITLE>Invalid day,hour,duration</TITLE>
            </HEAD>
            <BODY>
            Invalid day,hour or duration.
            </BODY>
            </HTML>
            `;
              socket.write(
                `HTTP/1.1 400 Bad Request\r\nContent-Length: ${response.length}\r\n\r\n${response}`
              );
              return;
            }

            // I will create a reservation
            const startTime = new Date();
            const currentDay = startTime.getDay();
            const desiredDay = day;
            const dayDifference = desiredDay - currentDay;

            startTime.setDate(startTime.getDate() + dayDifference);
            startTime.setHours(hour);
            startTime.setMinutes(0);

            const endTime = new Date(
              startTime.getTime() + duration * 60 * 60 * 1000
            );

            // We will check if the reservations in the database are in conflict time with the new reservation.
            const checkReservation = await Reservation.find({
              room_name: name,
            });
            for (let i = 0; i < checkReservation.length; i++) {
              const reservationStartTime = new Date();
              reservationStartTime.setDate(
                reservationStartTime.getDate() + dayDifference
              );
              reservationStartTime.setHours(checkReservation[i].hour);
              reservationStartTime.setMinutes(0);

              const reservationEndTime = new Date(
                reservationStartTime.getTime() +
                  checkReservation[i].duration * 60 * 60 * 1000
              );

              // If the new reservation is between the start and end time of the reservation in the database, it will be in conflict.
              if (
                checkReservation[i].day === day && // If the day is the same
                ((startTime >= reservationStartTime &&
                  startTime <= reservationEndTime) ||
                  (endTime >= reservationStartTime &&
                    endTime <= reservationEndTime) ||
                  (startTime <= reservationStartTime &&
                    endTime >= reservationEndTime))
              ) {
                const response = `
            <HTML>
            <HEAD>
            <TITLE> Room is already reserved </TITLE>
            </HEAD>
            <BODY>
            ${name} is already reserved at this time.
            </BODY>
            </HTML>
            `;
                socket.write(
                  `HTTP/1.1 403 Forbidden\r\nContent-Length: ${response.length}\r\n\r\n${response}`
                );
                return;
              }
            }

            // I will create a reservation
            const createReservation = await Reservation.create({
              room_name: name,
              hour: hour,
              day: day,
              duration: duration,
            });

            const startTimeString = startTime.toLocaleString("en-US", {
              hour: "2-digit",
              minute: "2-digit",
              hour12: false,
            });
            const endTimeString = endTime.toLocaleString("en-US", {
              hour: "2-digit",
              minute: "2-digit",
              hour12: false,
            });

            // I will send the response, the reservation is successful.
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Room Reservation Succesfull</TITLE>
            </HEAD>
            <BODY>
            Room ${name} is  on ${numberToDay[day]} ${startTimeString}-${endTimeString}.
            Your Reservation ID is ${createReservation._id}.
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 200 OK\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          } catch (error) {
            console.log(error);
            const response = "Error creating reservation";
            socket.write(
              `HTTP/1.1 500 Internal Server Error\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          }
          break;
        }

        // This part is extra for the cancel reservation.
        // I will delete the reservation with the given id.
        case "/cancel": {
          const { id } = queryParams;
          try {
            // I will check if the reservation exists.
            const deleteReservation = await Reservation.findByIdAndDelete(id);
            if (!deleteReservation) {
              const response = `
            <HTML>
            <HEAD>
            <TITLE>Reservation not found</TITLE>
            </HEAD>
            <BODY>
            Reservation not found.
            </BODY>
            </HTML>
            `;
              socket.write(
                `HTTP/1.1 404 Not Found\r\nContent-Length: ${response.length}\r\n\r\n${response}`
              );
              return;
            }
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Reservation cancelled</TITLE>
            </HEAD>
            <BODY>
            Reservation cancelled.
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 200 OK\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          } catch (error) {
            console.log(error);
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Reservation not found</TITLE>
            </HEAD>
            <BODY>
            Reservation not found.
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 404 Not Found\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          }
          break;
        }

        case "/checkavailability": {
          const { name, day } = queryParams;

          // List all available hours for a given day
          const numberToDay = {
            1: "Monday",
            2: "Tuesday",
            3: "Wednesday",
            4: "Thursday",
            5: "Friday",
            6: "Saturday",
            7: "Sunday",
          };

          // Check if x is not a valid day
          if (!numberToDay[day]) {
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Invalid day</TITLE>
            </HEAD>
            <BODY>
            Invalid day.
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 400 Bad Request\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
            return;
          }

          try {
            const findRoom = await Room.findOne({ name: name });

            if (!findRoom) {
              const response = `
            <HTML>
            <HEAD>
            <TITLE>Room doesn't exist</TITLE>
            </HEAD>
            <BODY>
            There is no room ${name}.
            </BODY>
            </HTML>
            `;
              socket.write(
                `HTTP/1.1 404 Bad Request\r\nContent-Length: ${response.length}\r\n\r\n${response}`
              );
              return;
            }

            // I will find the reservations for the room
            const findReservation = await Reservation.find({
              room_name: name,
              day: day,
            });

            // I will check if there is no reservation for the room
            if (!findReservation) {
              const response = `
            <HTML>
            <HEAD>
            <TITLE>There is no reservation</TITLE>
            </HEAD>
            <BODY>
            There is no reservation ${name}.
            </BODY>
            </HTML>
            `;
              socket.write(
                `HTTP/1.1 400 Bad Request\r\nContent-Length: ${response.length}\r\n\r\n${response}`
              );
              return;
            }

            const allHours = [];
            for (let i = 9; i <= 17; i++) {
              allHours.push(i);
            }

            // I will create an array with the reserved hours
            const reservedHours = findReservation.map((reservation) => {
              const startHour = reservation.hour;
              const endHour = startHour + reservation.duration;
              const reservedRange = [];

              for (let i = startHour; i < endHour; i++) {
                reservedRange.push(i);
              }
              return reservedRange;
            });

            // I will flatten the array
            const flattenedReservedHours = [].concat(...reservedHours);
            const availableHours = allHours.filter(
              (hour) => !flattenedReservedHours.includes(hour)
            );

            // I will send the response, available hours
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Available Hours</TITLE>
            </HEAD>
            <BODY>
            Room ${name} is available on ${numberToDay[day]} at ${availableHours}.
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 200 OK\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          } catch (error) {
            console.log(error);
            const response = "Error creating room";
            socket.write(
              `HTTP/1.1 500 Internal Server Error\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          }
        }
        // Any other path is not found (404)
        default:
          const response = `Page not found!`;
          socket.write(
            `HTTP/1.1 404 Not Found\r\nContent-Length: ${response.length}\r\n\r\n${response}`
          );
          break;
      }
    });
  });
  // Start the server
  server.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });
});
