
const mongoose = require('mongoose');

const schema = new mongoose.Schema({
    name: {
      type: String,
      required: true,
      unique: true,
    },

  });
  
const Room = mongoose.model('Room', schema);


module.exports = Room;
