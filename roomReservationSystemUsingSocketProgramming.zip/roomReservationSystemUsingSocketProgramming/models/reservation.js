const mongoose = require("mongoose");

const schema = new mongoose.Schema({
  room_name: {
    type:String,
    reqired:true,
  },
  activity_name: {
    type:String,
    reqired:true,
  },
  day: {
    type: Number,
    required: true,
  },
  hour: {
    type: Number,
    required: true,
  },
  duration: {
    type: Number,
    required: true,
  },
});

const Reservation = mongoose.model("Reservation", schema);

module.exports = Reservation;
