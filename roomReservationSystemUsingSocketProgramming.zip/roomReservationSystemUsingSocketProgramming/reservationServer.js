const net = require("net");
const mongoose = require("mongoose");

const port = 8080;

function parseRequest(data) {
  const [requestLine, ...rest] = data.toString().split("\r\n");
  const [method, path] = requestLine.split(" ");

  // Split the path by "?" and take the first element to get the path without the query string
  const [pathWithoutQueryString] = path.split("?");

  // Parse query string
  const queryString = path.split("?")[1] || "";
  const queryParams = queryString.split("&").reduce((params, param) => {
    const [key, value] = param.split("=");
    params[key] = value;
    return params;
  }, {});

  return {
    method,
    path: pathWithoutQueryString,
    queryParams,
  };
}

mongoose.connect("mongodb://127.0.0.1/room-reservation", {
  useNewUrlParser: true,
});

// mongodb models
const Room = require("./models/room");
const Reservation = require("./models/reservation");
const Activity = require("./models/activity");

const db = mongoose.connection;
db.on("error", function (error) {
  console.log(error);
});
db.once("open", function () {
  const server = net.createServer((socket) => {
    console.log("New connection");

    // Handle data from client
    socket.on("data", async (data) => {
      const { method, path, queryParams } = parseRequest(data);

      // If the request is not a GET request, return an error
      if (method !== "GET") {
        const response = `
        <HTML>
        <HEAD>
        <TITLE>ERROR</TITLE>
        </HEAD>
        <BODY>
        Server is only accepting GET requests.
        </BODY>
        </HTML>
        `;
        socket.write(
          `HTTP/1.1 403 Bad Request\r\nContent-Length: ${response.length}\r\n\r\n${response}`
        );
        return;
      }

      switch (path) {
        case "/reserve": {
          // now we first check if the activity exists
          const { room, activity, hour, duration, day } = queryParams;
          //   Check the room name if exists give an error message
          const findRoom = await Room.findOne({ name: room });
          if (!findRoom) {
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Room is not exist</TITLE>
            </HEAD>
            <BODY>
            There is no room ${room}.
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 404 Not Found\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
            return;
          }

          try {
            const findActivity = await Activity.findOne({ name: activity });
            if (!findActivity) {
              //  If the activity is not found give an error message
              const response = `
            <HTML>
            <HEAD>
            <TITLE>Activity is not found</TITLE>
            </HEAD>
            <BODY>
            There is no activity ${activity}.
            </BODY>
            </HTML>
            `;
              socket.write(
                `HTTP/1.1 404 Not Found\r\nContent-Length: ${response.length}\r\n\r\n${response}`
              );
              return;
            } else {
              // now I check if the room exists tries to reserve room for the specified date,hour and duration
              const reserveRoom = await Reservation.findOne({
                room_name: room,
                day,
                hour,
                duration: duration,
                activity_name: activity,
              });
              const numberToDay = {
                1: "Monday",
                2: "Tuesday",
                3: "Wednesday",
                4: "Thursday",
                5: "Friday",
                6: "Saturday",
                7: "Sunday",
              };
              // If the room is already reserved give an error message
              if (reserveRoom) {
                const response = `
              <HTML>
              <HEAD>
              <TITLE>Room is already reserved</TITLE>
              </HEAD>
              <BODY>
              Room ${room} is already reserved for activity ${activity} on ${
                  numberToDay[day]
                } ${reserveRoom.hour}:00-${
                  reserveRoom.hour + reserveRoom.duration
                }:00.
              </BODY>
              </HTML>
              `;
                socket.write(
                  `HTTP/1.1 403 Forbidden\r\nContent-Length: ${response.length}\r\n\r\n${response}`
                );
                return;
              }

              const checkHour = hour >= 9 && hour <= 17;
              const checkDuration = duration > 0 && duration <= 24;

              if (!numberToDay[day] || !checkHour || !checkDuration) {
                // Check if the day,hour and duration are valid
                const response = `
            <HTML>
            <HEAD>
            <TITLE>Invalid day,hour or duration</TITLE>
            </HEAD>
            <BODY>
            Invalid day,hour or duration.
            </BODY>
            </HTML>
            `;
                socket.write(
                  `HTTP/1.1 400 Bad Request\r\nContent-Length: ${response.length}\r\n\r\n${response}`
                );
                return;
              }

              // We will check if the reservations in the database are in conflict time with the new reservation.
              const startTime = new Date();
              const currentDay = startTime.getDay();
              const desiredDay = day;
              const dayDifference = desiredDay - currentDay;

              startTime.setDate(startTime.getDate() + dayDifference);
              startTime.setHours(hour);
              startTime.setMinutes(0);

              const endTime = new Date(
                startTime.getTime() + duration * 60 * 60 * 1000
              );

              // We will check if the reservations in the database are in conflict time with the new reservation.
              const checkReservation = await Reservation.find({
                room_name: room,
              });
              for (let i = 0; i < checkReservation.length; i++) {
                const reservationStartTime = new Date();
                reservationStartTime.setDate(
                  reservationStartTime.getDate() + dayDifference
                );
                reservationStartTime.setHours(checkReservation[i].hour);
                reservationStartTime.setMinutes(0);

                const reservationEndTime = new Date(
                  reservationStartTime.getTime() +
                    checkReservation[i].duration * 60 * 60 * 1000
                );

                // If the new reservation is between the start and end time of the reservation in the database, it will be in conflict.
                if (
                  // If the new reservation day is not equal to the reservation day in the database, it will not be in conflict.
                  checkReservation[i].day === day && 
                  (startTime >= reservationStartTime &&
                    startTime <= reservationEndTime) ||
                    (endTime >= reservationStartTime &&
                      endTime <= reservationEndTime) ||
                    (startTime <= reservationStartTime &&
                      endTime >= reservationEndTime)
                ) {
                  // If the room is already reserved give an error message
                  const response = `
            <HTML>
            <HEAD>
            <TITLE>Room is already reserved at this time</TITLE>
            </HEAD>
            <BODY>
            ${room} is already reserved at this time.
            </BODY>
            </HTML>
            `;
                  socket.write(
                    `HTTP/1.1 403 Forbidden\r\nContent-Length: ${response.length}\r\n\r\n${response}`
                  );
                  return;
                }
              }

              // If the room is not reserved, we will create a new reservation.
              const createReservation = await Reservation.create({
                room_name: room,
                hour: hour,
                day: day,
                duration: duration,
                activity_name: activity,
              });

              const startTimeString = startTime.toLocaleString("en-US", {
                hour: "2-digit",
                minute: "2-digit",
                hour12: false,
              });
              const endTimeString = endTime.toLocaleString("en-US", {
                hour: "2-digit",
                minute: "2-digit",
                hour12: false,
              });

              // Reservation is successful
              const response = `
            <HTML>
            <HEAD>
            <TITLE>Reservation Successfull</TITLE>
            </HEAD>
            <BODY>
            Room ${room} is reserved for activity ${activity} on ${numberToDay[day]} ${startTimeString}-${endTimeString}.
            Your Reservation ID is ${createReservation._id}.
            </BODY>
            </HTML>
            `;
              socket.write(
                `HTTP/1.1 200 OK\r\nContent-Length: ${response.length}\r\n\r\n${response}`
              );
            } // end of else
          } catch (error) {
            console.log(error);
            const response = "Error creating reservation";
            socket.write(
              `HTTP/1.1 500 Internal Server Error\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          }
          break;
        }
        case "/listavailability": {
          const { room, day } = queryParams;
          // List all available hours for a given day
          const numberToDay = {
            1: "Monday",
            2: "Tuesday",
            3: "Wednesday",
            4: "Thursday",
            5: "Friday",
            6: "Saturday",
            7: "Sunday",
          };

          // Check if x is not a valid day
          if (!numberToDay[day]) {
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Invalid day</TITLE>
            </HEAD>
            <BODY>
            Invalid day
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 400 Bad Request\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          }

          const findReservation = await Reservation.find({
            room_name: room,
            day: day,
          });
          // Check if the room is not reserved
          if (!findReservation) {
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Reservation is not exist</TITLE>
            </HEAD>
            <BODY>
            There is no reservation ${room}.
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 400 Bad Request\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          }

          // check all hours
          const allHours = [];
          for (let i = 9; i <= 17; i++) {
            allHours.push(i);
          }

          // find the reserved hours
          const reservedHours = findReservation.map((reservation) => {
            const startHour = reservation.hour;
            const endHour = startHour + reservation.duration;
            const reservedRange = [];
            for (let i = startHour; i <= endHour; i++) {
              reservedRange.push(i);
            }
            return reservedRange;
          });

          // Flatten the array
          const flattenedReservedHours = [].concat(...reservedHours);
          const availableHours = allHours.filter(
            (hour) => !flattenedReservedHours.includes(hour)
          );
          // Available hours
          const response = `
          <HTML>
          <HEAD>
          <TITLE>Available Hours</TITLE>
          </HEAD>
          <BODY>
          Room ${room} is available on ${numberToDay[day]} at ${availableHours}.
          </BODY>
          </HTML>
          `;
          socket.write(
            `HTTP/1.1 200 OK\r\nContent-Length: ${response.length}\r\n\r\n${response}`
          );
          return;
        }

        // This is an extra endpoint to list all available hours for a given week
        case "/listavailabilityweekly": {
          const { room } = queryParams;

          const numberToDay = {
            1: "Monday",
            2: "Tuesday",
            3: "Wednesday",
            4: "Thursday",
            5: "Friday",
            6: "Saturday",
            7: "Sunday",
          };

          const checkifExist = await Room.findOne({ name: room });

          if (!checkifExist) {
            // There is exists room with this name
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Does Not Exists Room</TITLE>
            </HEAD>
            <BODY>
             There is no Room ${room}
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 403 Forbidden\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
            return;
          }

          // Create a function for  available hours for each day
          const availableHours = async (day) => {
            const findReservation = await Reservation.find({
              room_name: room,
              day: day,
            });
            const allHours = [];
            for (let i = 9; i <= 17; i++) {
              allHours.push(i);
            }
            const reservedHours = findReservation.map((reservation) => {
              const startHour = reservation.hour;
              const endHour = startHour + reservation.duration;
              const reservedRange = [];
              for (let i = startHour; i <= endHour; i++) {
                reservedRange.push(i);
              }
              return reservedRange;
            });
            const flattenedReservedHours = [].concat(...reservedHours);
            const availableHours = allHours.filter(
              (hour) => !flattenedReservedHours.includes(hour)
            );
            return availableHours;
          };

          // Find all reservations for the given room
          const reservations = await Reservation.find({ room_name: room });

          // Create an object to store the availability for each day of the week
          const availability = {
            Monday: [],
            Tuesday: [],
            Wednesday: [],
            Thursday: [],
            Friday: [],
            Saturday: [],
            Sunday: [],
          };

          // Iterate through the reservations and mark the unavailable hours for each day
          reservations.forEach((reservation) => {
            const day = numberToDay[reservation.day];
            for (
              let i = reservation.start_time;
              i < reservation.end_time;
              i++
            ) {
              availability[day][i] = false;
            }
          });

          const response = `
          <HTML>
          <HEAD>
          <TITLE>Availability for ${room}</TITLE>
          </HEAD>
          <BODY>
          Monday: ${await availableHours(1)}
          Tuesday: ${await availableHours(2)}
          Wednesday: ${await availableHours(3)}
          Thursday: ${await availableHours(4)}
          Friday: ${await availableHours(5)}
          Saturday: ${await availableHours(6)}
          Sunday: ${await availableHours(7)}
          </BODY>
          </HTML>

          `;

          // Send the response to the client
          socket.write(
            `HTTP/1.1 200 OK\r\nContent-Length: ${response.length}\r\n\r\n${response}`
          );
          return;
        }

        case "/display": {
          const { id } = queryParams;
          const numberToDay = {
            1: "Monday",
            2: "Tuesday",
            3: "Wednesday",
            4: "Thursday",
            5: "Friday",
            6: "Saturday",
            7: "Sunday",
          };

          try {
            // Check if the id is valid
            const findIdDetails = await Reservation.findById(id);
            if (!findIdDetails) {
              const response = `
              <HTML>
              <HEAD>
              <TITLE>Reservation not found</TITLE>
              </HEAD>
              <BODY>
              Reservation with id ${id} not found.
              </BODY>
              </HTML>
              `;
              socket.write(
                `HTTP/1.1 404 Not Found\r\nContent-Length: ${response.length}\r\n\r\n${response}`
              );
            }
            // Display the reservation details
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Reservation Info</TITLE>
            </HEAD>
            <BODY>
            Room: ${findIdDetails.room_name} <br> 
            Activity: ${findIdDetails.activity_name}  <br> 
            When: ${numberToDay[findIdDetails.day]} ${findIdDetails.hour}:00-${
              findIdDetails.hour + findIdDetails.duration
            }:00.
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 200 OK\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          } catch (err) {
            // Invalid id
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Reservation not found</TITLE>
            </HEAD>
            <BODY>
            Reservation with id not found.
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 404 Not Found\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          }
        }
        // If the path is not found
        default:
          const response = `Page not found!`;
          socket.write(
            `HTTP/1.1 404 Not Found\r\nContent-Length: ${response.length}\r\n\r\n${response}`
          );
          break;
      }
    });
  });
  // Start the server
  server.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });
});
