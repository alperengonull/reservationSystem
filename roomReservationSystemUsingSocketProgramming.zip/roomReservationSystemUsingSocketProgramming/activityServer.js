const net = require("net");
const mongoose = require("mongoose");

const port = 8082;

function parseRequest(data) {
  const [requestLine, ...rest] = data.toString().split("\r\n");
  const [method, path] = requestLine.split(" ");

  // Split the path by "?" and take the first element to get the path without the query string
  const [pathWithoutQueryString] = path.split("?");

  // Parse query string
  const queryString = path.split("?")[1] || "";
  const queryParams = queryString.split("&").reduce((params, param) => {
    const [key, value] = param.split("=");
    params[key] = value;
    return params;
  }, {});

  return {
    method,
    path: pathWithoutQueryString,
    queryParams,
  };
}

mongoose.connect("mongodb://127.0.0.1/room-reservation", {
  useNewUrlParser: true,
});

// mongodb models
const Activity = require("./models/activity");

const db = mongoose.connection;
db.on("error", function (error) {
  console.log(error);
});
db.once("open", function () {
  const server = net.createServer((socket) => {
    console.log("New connection");

    // Handle data from client
    socket.on("data", async (data) => {
      const { path, method, queryParams } = parseRequest(data);

      // If the request is not a GET request, return an error
      if (method !== "GET") {
        const response = `
        <HTML>
        <HEAD>
        <TITLE>ERROR</TITLE>
        </HEAD>
        <BODY>
        Server is only accepting GET requests.
        </BODY>
        </HTML>
        `;
        socket.write(
          `HTTP/1.1 403 Bad Request\r\nContent-Length: ${response.length}\r\n\r\n${response}`
        );
        return;
      }
      switch (path) {
        case "/add": {
          // name is the query parameter
          const { name } = queryParams;
          // Check if activity already exist
          const checkifExistActivity = await Activity.findOne({
            name: name,
          });

          // If activity already exist, return an error
          if (checkifExistActivity) {
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Activity Already Exist</TITLE>
            </HEAD>
            <BODY>
              Activity with name ${name} already exist.
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 403 Bad Request\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
            return;
          }
          try {
            // Add activity to database
            await Activity.create({ name: name });
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Activity Added</TITLE>
            </HEAD>
            <BODY>
              Activity with name ${name} is successfully added.
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 200 OK\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          } catch (error) {
            console.log(error);
            const response = "Error adding activity";
            socket.write(
              `HTTP/1.1 500 Internal Server Error\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          }
          break;
        }
        case "/remove": {
          const { name } = queryParams;
          const checkifExistActivity = await Activity.findOne({ name: name });

          // If activity does not exist, return an error
          if (!checkifExistActivity) {
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Activity is not exist</TITLE>
            </HEAD>
            <BODY>
              Activity with name ${name} does not exist.
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 403 Bad Request\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
            return;
          }
          try {
            await Activity.deleteOne({ name: name });
            // Activity removed successfully
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Activity removed</TITLE>
            </HEAD>
            <BODY>
              Activity with name ${name} is successfully removed.
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 200 OK\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          } catch (error) {
            console.log(error);
            const response = "Error removing activity";
            socket.write(
              `HTTP/1.1 500 Internal Server Error\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          }
          break;
        }
        case "/check": {
          const { name } = queryParams;
          const checkifExistActivity = await Activity.findOne({ name: name });
          // If activity already exist, return an error
          if (checkifExistActivity) {
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Activity exist</TITLE>
            </HEAD>
            <BODY>
              Activity with name ${name} already exist.
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 202 OK\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
            return;
          }
          try {
            // Activity does not exist
            const response = `
            <HTML>
            <HEAD>
            <TITLE>Activity is not exist</TITLE>
            </HEAD>
            <BODY>
              Activity with name ${name} does not exist.
            </BODY>
            </HTML>
            `;
            socket.write(
              `HTTP/1.1 404 NOT FOUND\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          } catch (error) {
            console.log(error);
            const response = "Error checking activity";
            socket.write(
              `HTTP/1.1 500 Internal Server Error\r\nContent-Length: ${response.length}\r\n\r\n${response}`
            );
          }
          break;
        }
        // If the path is not one of the above, return an error
        default:
          const response = `Page not found!`;
          socket.write(
            `HTTP/1.1 404 Not Found\r\nContent-Length: ${response.length}\r\n\r\n${response}`
          );
          break;
      }
    });
  });
  // Start the server
  server.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });
});
